const CACHE_NAME = 'infinite-unlocker-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/utils.js',
  '/int64.js',
  '/stages.js',
  '/offsets.js',
  '/pwn.js',
  '/manifest.json',
  '/favicon.ico'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Don't cache OAuth redirects or Lovable internal requests
  if (event.request.url.includes('/~oauth')) return;
  if (event.request.url.includes('__lovable')) return;
  if (event.request.url.includes('/src/')) return;
  if (event.request.url.includes('node_modules')) return;
  if (event.request.url.includes('@') ) return;

  // Network-first: try network, fall back to cache
  event.respondWith(
    fetch(event.request).then((response) => {
      if (response.status === 200) {
        const clone = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
      }
      return response;
    }).catch(() => caches.match(event.request).then((cached) => cached || caches.match('/')))
  );
});
